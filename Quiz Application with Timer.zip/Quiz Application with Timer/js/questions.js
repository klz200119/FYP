// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Where was COVID-19 first identified?",
    answer: "Wuhan, China",
    options: [
      "Beijing, China",
      "Xi An, China",
      "Guang Dong, China",
      "Wuhan, China"
    ]
  },
    {
    numb: 2,
    question: "What is the total number of case in worldwide on 9/8/2021?",
    answer: "203,483,267",
    options: [
      "100,012,330",
      "203,483,267",
      "998,035,127",
      "303,876,154"
    ]
  },
    {
    numb: 3,
    question: "Which country has the highest count of case on 9/8/2021?",
    answer: "America",
    options: [
      "America",
      "India",
      "France",
      "New Zealand"
    ]
  },
    {
    numb: 4,
    question: "In Singapore, which category in F&B took the hardest toll during Circuit Breaker",
    answer: "Restaurants",
    options: [
      "Cafe",
      "Fast Food Outlets",
      "Food Caterers",
      "Restaurants"
    ]
  },
    {
    numb: 5,
    question: "What causes the decline on the index of department stores?",
    answer: "Non-Essential Business Closure",
    options: [
      "Non-Essential Business Closure",
      "Productivity Solution Grant for SMEs",
      "Circuit Breaker",
      "Ban Of Social Gathering"
    ]
  },
     {
     numb: 6,
     question: "What is the percetnage of Community Case In Singapore?",
     answer: "9.99%",
     options: [
       "7.63%",
       "82.38%",
       "12.77%",
       "9.99%"
     ]
   },
   {
   numb: 7,
   question: "Which phase in Singapore has the most Covid-19 Cases?",
   answer: "Phase 2",
   options: [
     "Circuit Breaker",
     "Phase 3",
     "Phase 2",
     "Phase 2 (Heightened Alert)"
      ]
    },
    {
    numb: 8,
    question: "What is the percentage of Imported Cases in Singapore?",
    answer: "7.63%",
    options: [
      "7.63%",
      "7.88%",
      "6.33%",
      "5.23%"
    ]
  },
     {
     numb: 8,
     question: "During which month of 2021, visitor arrival in Singapore grow by 333,2% Year Over Year?",
     answer: "April",
     options: [
       "March",
       "April",
       "May",
       "January"
     ]
   },
   {
   numb: 10,
   question: "What causes the spike in Average Length Of Stay in Singapore?",
   answer: "Quarrantine Order By Singapore Government",
   options: [
     "More visitor in Singapore",
     "Less visitors in Singapore",
     "People spend more time to travel in Singapore",
     "Quarrantine Order By Singapore Government"
      ]
    },
];
